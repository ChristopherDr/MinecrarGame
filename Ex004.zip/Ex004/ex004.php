
<?php

                                /* ============================== HERO ====================================== */

$hero = [ 
    "name" => "Steve",
    "life" =>  10
    //"fome" => 10,
];

                                /* ============================== FOOD ====================================== */

                                
$badFruits = [
    "name" => "Bagas",
    "dmg" => rand(1, 2)
];


$food = [
    "name" => "apple",
    "cure" => rand(1, 3)
];
                                /* ============================== WEAPONS ====================================== */




$stick = [ 
    "name" => "Stick",
    "dmg" => rand(2, 3)
];

                                /* ============================== ENEMYS ====================================== */


$zombie = [
    "name" => "Zumbi",
    "life" => 6,
    "dmg" => rand(2, 3)
];
                                /* ============================== Functions ====================================== */

//variavel que possui o a vida do heroi.

//Apenas anuncia a morte do heroi.
function heroLost(){
    echo "</br></br>Steve <strong>não resistiu aos ferimentos  e sucumbiu</strong> perante seu inimigo.</br>";
    
}

function enemyLost($enemyName = 1){
    echo "</br> O $enemyName não suportou os ferimentos e <strong>sucumbiu</strong> perante a furia do herói.</br>";
    echo "com isso Steve sobrevive ao  $enemyName e <strong> consegue escapar </strong>. ";
}


//calcula a vida perdida do heroi.
function heroLife($monster, $hero){
    $hero_life = $hero['life'] - $monster['dmg'];

    if ($hero['life'] <= 0){
        return heroLost();
    }
    return $hero_life;
} 

$hero_life = heroLife($badFruits, $hero);

//calcula a vida que o heroi cura/recupera.
function heroCure($cure, $hero_life){
    $hero_life += $cure['cure'];
    if($hero_life > 10){
        $hero_life = 10;
    }
    return $hero_life;
}

function line(){
    $line = "";
    for($i=150; $i > 0; $i--){
        $line .= "=";
    
    }
    echo "$line</br>";
}

//Função de duelo, onde o heroi duela contra um inimigo.
function duel($enemyDmg, $enemyLife,  $enemyName, $weaponDmg, $heroLife ){
    line();
    while(true){
        echo "O $enemyName, possui <strong> $enemyLife de vida </strong>. </br>Enquanto o heroi <strong> possui $heroLife</strong>!</br></br>";

        $enemyLife -= $weaponDmg;
        $heroLife -= $enemyDmg;

        echo "</br>Zumbi atacou Steve e <strong>deu $enemyDmg de dano!</strong>";
        echo "</br>O heroi <strong>causou $weaponDmg de dano</strong>!";

        if ($enemyLife <= 0){
            enemyLost($enemyName);
            break;
        }
        if ($heroLife < 1){
             heroLost();
            exit;
        }
    }
    line();


}



                                /* ============================== TEXT ====================================== */
                                
$regnLife = $food['cure'];


echo " Com um barulho ensurdecedor, o herói acorda sem saber onde está.
Ele abre os olhos e verifica o local, parece uma floresta, com arvores baixas e algumas frutas no chão</br></br>
 Ao se aproximar das frutas no chão, ela o machuca <strong> retirando ".$badFruits['dmg']. " </strong>
 de vida ficando com <strong> ".heroLife($badFruits, $hero)."  de vida</strong>.<br>
Steve vai embora atrás de maçãs nas arvores, ao comer as maças, Steve se sente revigorado ficando com 
".heroCure($food, $hero_life)." de vida.";

echo " </br></br> Sem menos perceber, <strong>  " . $hero['name'] ." </strong>  estava na floresta, escura, e ouvindo barulhos se aproximando. 
Steve  rapidamente  procura algo para se defender";

echo " </br> A unica coisa que estava perto era um galho de arvore, ao pegar o galho o barulho se aproxima e Steve está pronto para o ataque. 
</br>No meio da escuridão, aparece um ZUMBI, onde tenta agarrar steve."; 

echo " Por sua vez, " . $hero['name'] ." se esquiva e inicia um duelo</br>";

duel($zombie['dmg'],  $zombie['life'], $zombie['name'], $stick['dmg'], $hero_life);





