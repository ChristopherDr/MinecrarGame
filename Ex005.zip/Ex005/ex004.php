<?php 


function badFruit($badfruit, $survivorLife){
    return $survivorLife -= $badfruit;
}

function eatFood($fruitCure, $fruitQtd, $survivorLife){

        while($survivorLife < 10){

            if($fruitQtd > 0){
                $survivorLife += $fruitCure;
                $fruitQtd -= 1;

                if($survivorLife >= 10){
                    $survivorLife = 10;
                    break;
                }
            } else if($fruitQtd == 0){
                echo "Não há maçãs na bolsa.";
                break;
            }
        }
       return [$survivorLife, $fruitQtd];
}



function enemyLost(){
    echo "O inimigo pereceu!";
}

function survLost(){
    echo "Steve perdeu a vida na batalha!";
}


$survivor = [
    "name" => "Steve",
    "life" => 10,
    "hungry" => 10
];

$weapon = [ 
    "name" => "stick",
    "dmg" => rand(1, 3)
];

$badFruits = [
    "name" => "baga",
    "dmg" => rand(1, 2)
];

$enemyOne = [
    "name" => "Zombie",
    "life" => 4,
    "dmg" => rand(1, 2)
];

$food = [
    "name" => "apple",
    "cure" => rand(2, 3),
    "qtd" => rand(3, 5)
];

$baga = badFruit($badFruits['dmg'], $survivor['life']);



$enemyLife = $enemyOne['life'];
$enemyDmg = $enemyOne['dmg'];
$weaponDmg = $weapon['dmg'];
$survivorLife = $baga;

$apple = eatFood($food['cure'], $food['qtd'], $survivorLife);

/* ======================================== */

echo $food['cure'];

echo "Com um barulho ensurdecedor, o herói acorda sem saber onde está.
 Ele abre os olhos e verifica o local, parece uma floresta, com arvores baixas e algumas frutas no chão.</br>
 Ao se aproximar das frutas no chão, ela o machuca <strong> retirando {$badFruits['dmg']}</strong>
 de vida ficando com <strong> {$baga} de vida</strong>.<br>
 Steve vai embora atrás de maçãs nas arvores, ao comer as maças, ele se sente revigorado ficando com <strong>{$apple[0]}
 de vida e possui {$apple[1]} maças</strong>.";


echo "Sem menos perceber, Steve estava na floresta, escura, e ouvindo barulhos se aproximando. Rapidamente 
procura algo para se defender , a unica coisa que, era um {$weapon['name']} de arvore, ao pega-lo
o barulho se aproxima e Steve está pronto para o ataque. No meio da escuridão, aparece um ZUMBI, que parte para cima de Steve.";

while(true){
    echo "<br>";
    $enemyLife -= $weaponDmg;
    $survivorLife -= $enemyDmg;

    echo "O inimigo perdeu {$weaponDmg} de vida.";
    echo "Steve perdeu {$enemyDmg} de vida.";

    if($enemyLife <= 0){
        echo "<br>O inimigo pereceu.<br>";
        break;

    } else if($survivorLife <= 0){
        echo "Steve pereceu perante seu inimigo.<br>";
    }
    
    echo "<br>";
}

echo "Steve, após vencer seu inimigo, procurou em sua mochila se havia comida pra se recuperar, olhando dentro da mochila viu que
havia {$apple[1]} maçãs.";

$lifeAtual = eatFood($food['cure'],$apple[1], $survivorLife);

echo "Após comer, o herói está com {$lifeAtual[0]} de vida e {$lifeAtual[1]} maçãs";




