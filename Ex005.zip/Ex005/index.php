<?php

echo "Iniciando jogo...<br>";

$times = ['manhã', 'tarde', 'noite'];
$actor = ['name' => "Steve"];

$game = [
    'day_time' => 0,
    'timer' => 0,
    'actor' => $actor,
    'time_interval' => 100
];

function day_interval($day_time, $times_total)
{
    return ($day_time < ($times_total - 1)) ? ($day_time + 1) : 0;
}

while (true) {

    $game['timer']++;

    $hundred = $game['timer'] % $game['time_interval'] == 0;
    $game['day_time'] = day_interval($game['day_time'], count($times));

    echo "Nosso amado personagem {$actor['name']} acorda em uma linda {$times[$game['day_time']]}<br>";

    if ($game['timer'] > 999)
        break;
}

echo "Fim de jogo!";
